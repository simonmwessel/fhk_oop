Simon Wessel - 947341
See git repositorys for history, Gradle config etc.: 
Github: https://github.com/simonmwessel/fhk_oop
Gitlab: https://gitlab.iue.fh-kiel.de/simon.wessel/oop
